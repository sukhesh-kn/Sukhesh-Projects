#SVM for reliance
Rel=read.csv("HINDUNILVR.csv",header=TRUE)
head(Rel)
daily_data=unclass(Rel)
head(daily_data)
days=249:2683
DF <- data.frame(days,daily_data$Close.Price[249:2683])
colnames(DF)<-c("x","y")
DF

library(e1071)
library(forecast)
library(nnfor)

svmodel <- svm(y ~ x,data=DF, type="eps-regression",kernel="radial")
?svm
nd <- 249:2683
length(nd)
#compute forecast for all the 156 months 
prognoza <- predict(svmodel, newdata=data.frame(x=nd))
accuracy(prognoza,DF$y)
fore=ts(prognoza,frequency=269,start=c(2012))
fore
length(fore)

nd1=2684:2952
prognoza1 <- predict(svmodel, newdata=data.frame(x=nd1))
fore1=ts(prognoza1,frequency = 269,start=c(2021))

tt=ts(daily_data$Close.Price,frequency=269,start=c(2012))
tt
plot.ts(tt)

y1=ts(DF$y,frequency=269,start=c(2012))

plot.ts(y1, type="l",col="black",ylim=c(400,3500), xlim=c(2011,2022),main="SVM-time series model",ylab="Closing Price")
par(new=TRUE)
plot(fore, type="l",col="red", ylim=c(400,3500), xlim=c(2011,2022),ylab="Closing Price")

plot.ts(y1, type="l",col="black",ylim=c(400,3500), xlim=c(2011,2022),main="SVM-time series model",ylab="Closing Price")
par(new=TRUE)
plot(fore1, type="l",col="red", ylim=c(400,3500), xlim=c(2011,2022),ylab="Closing Price")


##
library(nnfor)
CP=ts(DF$y,frequency = 269,start=c(2012))
head(CP)
class(CP)
elmfit=elm(CP)
elmfit

library(nnfor)
CP=ts(DF$y,frequency = 269,start=c(2012))
head(CP)
class(CP)
mlpfit=mlp(CP)
mlpfit


library(carit)
