#Portfolio
require(timeSeries)
require(quantmod)
require(slam)
require(fPortfolio)
require(caTools)
library(PerformanceAnalytics)

A=read.csv("Reliance.csv");A
B=read.csv("HDFC.csv");B
C=read.csv("INFY.csv");C
D=read.csv("HINDUNILVR.csv");D
E=read.csv("TCS.csv");E

X1=A$Close.Price[249:2683];X1
X2=B$Close.Price[249:2683];X2
X3=C$Close.Price[249:2683];X3
X4=D$Close.Price[249:2683];X4
X5=E$Close.Price[249:2683];X5

##Returns for each company
rt1={}
for( i in 1:2435){
  rt1[i]=(X1[i+1]-X1[i])/X1[i]
}
rt1

rt2={}
for( i in 1:2435){
  rt2[i]=(X2[i+1]-X2[i])/X2[i]
}
rt2

rt3={}
for( i in 1:2435){
  rt3[i]=(X3[i+1]-X3[i])/X3[i]
}
rt3

rt4={}
for( i in 1:2435){
  rt4[i]=(X4[i+1]-X4[i])/X4[i]
}
rt4

rt5={}
for( i in 1:2435){
  rt5[i]=(X5[i+1]-X5[i])/X5[i]
}
rt5

RT=data.frame("HDFC"=X1,"Reliance"=X2,"Infosys"=X3,"HU"=X4,"TCS"=X5);
head(RT)
RT=as.timeSeries(RT)
ret=as.timeSeries((tail(RT,-1)/as.numeric(head(RT,-1)))-1);ret
(Frontier<-portfolioFrontier(ret))
getWeights(Frontier)

write.csv(Frontier,"Frontier.csv")
plot(Frontier,1)
plot(Frontier)



