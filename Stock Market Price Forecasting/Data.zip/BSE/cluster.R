#Portfolio
require(timeSeries)
require(quantmod)
require(slam)
require(fPortfolio)
require(caTools)
library(PerformanceAnalytics)

A=read.csv("Reliance.csv");A
B=read.csv("HDFC.csv");B
C=read.csv("INFY.csv");C
D=read.csv("HINDUNILVR.csv");D
E=read.csv("TCS.csv");E

X1=A$Close.Price[249:2683];X1
X2=B$Close.Price[249:2683];X2
X3=C$Close.Price[249:2683];X3
X4=D$Close.Price[249:2683];X4
X5=E$Close.Price[249:2683];X5


rt1={}
for( i in 1:2435){
  rt1[i]=(X1[i+1]-X1[i])/X1[i]
}
rt1

rt2={}
for( i in 1:2435){
  rt2[i]=(X2[i+1]-X2[i])/X2[i]
}
rt2

rt3={}
for( i in 1:2435){
  rt3[i]=(X3[i+1]-X3[i])/X3[i]
}
rt3

rt4={}
for( i in 1:2435){
  rt4[i]=(X4[i+1]-X4[i])/X4[i]
}
rt4

rt5={}
for( i in 1:2435){
  rt5[i]=(X5[i+1]-X5[i])/X5[i]
}
rt5
length(rt1)
RT=data.frame("HDFC"=X1,"Reliance"=X2,"Infosys"=X3,"HU"=X4,"TCS"=X5);
head(RT)
class(RT)
kmeans(t(RT),2)
b=dist(t(RT))
h=hclust(b)
plot(h)
ct=cutree(h,3)
plot(ct)

X11=ts(X1,frequency=269,start=c(2012))
Return.calculate(X11)

#(RT=cbind(rt1,rt2,rt3,rt4,rt5))
kmeans(mtcars,2)
RT=as.timeSeries(RT)
length(RT)
class(RT)
head(RT)
portfolioFrontier(RT)

ret=as.timeSeries((tail(RT,-1)/as.numeric(head(RT,-1)))-1);ret

(Frontier<-portfolioFrontier(ret))
plot(Frontier,1)
plot(Frontier)
getStatistics(Frontier)$mean
cor(ret)
summary(Frontier)
RRP=frontierPoints(Frontier)#risk return points
RRP
AP=data.frame(targetrisk=RRP[,"targetRisk"]*sqrt(269),targetreturn=RRP[,"targetReturn"]*(269))
AP #annualised points

RFR=0
plot((AP[,"targetreturn"]-RFR)/AP[,"targetrisk"])


SharpeRatio(RT1)
class(RT1)
plot(AP)
table.AnnualizedReturns(RT1)

getWeights(Frontier@portfolio)


weig2=c(0.253,0.375,0.2732,0.0000,0.0983)
expinv=weig2*1000000
weig3=c(0.0722,0.3056,0.2768,0.0000,0.3454)
weig4=c(0.0000,0.1315 ,0.2617,0.0000,0.6068)
meanret=c(mean(r1),mean(r2),mean(r3))
expinv2=weig2*1000000
obmeanret=0.0007
portret2=(weig2*obmeanret)
plot(Frontier,1)
minVar<-minvariancePortfolio(returns)
summary(minVar)
sp=SharpeRatio(returns)
sd=StdDev(returns)
