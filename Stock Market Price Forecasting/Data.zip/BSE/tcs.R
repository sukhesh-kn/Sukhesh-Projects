A3=read.csv("TCS.csv");A3
X3=A3$Close.Price;X3
xt=ts(X3)
plot.ts(xt,main="Closing price of TCS",xlab="Time points(in days)",ylab="Closing Price")

train=xt[500:2683]

##TREND
library(Kendall)
summary(MannKendall(train))
pvalue=0.00000000000000222
if(pvalue<0.05)
  cat("\n There is trend \n")else
    cat("\n There is no trend \n")
library(forecast)
auto.arima(xt,d=NA)
v=var(train);v
d1=diff(train)
v1=var(d1);v1
d2=diff(d1);d2
v2=var(d2);v2
acf(d2)
pacf(d2)
fit1=arima(train,order=c(16,1,1))
fi1=fitted(fit1)
b1=Box.test(fit1$residual,lag=2*sqrt(length(train)))
b1

res=fit1$residuals
par(mfrow=c(2,2))
res
acf(res,main="ACF of adjusted Close price")
acf(res^2,main="ACF of adjusted squared Close price")
pacf(res,main="PACF of adjusted Close price")
pacf(res^2,main="PACF of adjusted squared Close price")
fore=forecast(fit1,h=365)
plot(fore)
accuracy(fit1)



#

library(fGarch)
library(tseries)
gft1=garchFit(~garch(1,1),data=res,cond.dist=c("snorm"))
summary(gft1)
rs1=residuals(gft1, standardize=T)
l1=Box.test(rs1,lag=round(2*sqrt(length(train))),type="Ljung-Box");l1

pr=predict(gft1, n.ahead =365 , trace = TRUE, mse = c("cond","uncond"),plot=TRUE, nx=NULL, crit_val=NULL, conf=0.95);pr
pr
pr1=data.frame(pr)
attach(pr1)
PointFor1=pr1[,1]
print(pr1)
testpred=forecast(fit1,h=365);testpred
testpred1=data.frame(testpred)
attach(testpred1)
PointFor=testpred1[,1]
print(testpred1)
foreca=PointFor+PointFor1;foreca
for1=data.frame(foreca)
plot(foreca)
foreca=ts(foreca,frequency=365,start=c(2684,1))
head(foreca)

final=c(train,foreca)
length(final)
plot(final,type="l",xlim=c(0,2900))
lines(1:2435,train,col=1)
lines(2436:2800,foreca,col="red")
accuracy(fit1)

# Hybrid Method
library(forecastHybrid)
mod1=hybridModel(train,model="an")
fore=forecast(mod1,h=269)
plot(fore)
accuracy(fore)
