
A1=read.csv("HDFC.csv");A1
X1=A1$Close.Price;X1
n1=length(X1);n1
xt=ts(X1)
plot.ts(xt,main="close price of HDFC")

train=xt[249:2683]

##TREND
library(Kendall)
summary(MannKendall(train))
pvalue=0.00000000000000222
if(pvalue<0.05)
  cat("\n There is trend \n")else
    cat("\n There is no trend \n")
library(forecast)
auto.arima(xt,d=NA)
v=var(train);v
d1=diff(train)
v1=var(d1);v1
d2=diff(d1);d2
v2=var(d2);v2
acf(d2)
pacf(d2)
fit1=arima(train,order=c(9,2,1))
fi1=fitted(fit1)
b1=Box.test(fit1$residual,lag=2*sqrt(length(train)))
b1

res=fit1$residuals
par(mfrow=c(2,2))
res
acf(res,main="ACF of adjusted log return series")
acf(res^2,main="ACF of adjusted squared log return series")
pacf(res,main="PACF of adjusted log return series")
pacf(res^2,main="PACF of adjusted squared log return series")
library(fGarch)
library(tseries)
gft1=garchFit(~garch(1,1),data=res,cond.dist=c("snorm"))
summary(gft1)
rs1=residuals(gft1, standardize=T)
l1=Box.test(rs1,lag=round(2*sqrt(length(train))),type="Ljung-Box");l1
#
v1=volatility(gft1);v1
V=fi1+v1;V
plot(train,type="p")
lines(V,col=2)
accuracy(gft1)
pr=predict(gft1, n.ahead =365 , trace = TRUE, mse = c("cond","uncond"),plot=TRUE, nx=NULL, crit_val=NULL, conf=0.95);pr
pr
pr1=data.frame(pr)
attach(pr1)
PointFor1=pr1[,1]
print(pr1)
testpred=forecast(fit1,h=365);testpred
testpred1=data.frame(testpred)
attach(testpred1)
PointFor=testpred1[,1]
print(testpred1)
foreca=PointFor+PointFor1;foreca
for1=data.frame(foreca)
plot(foreca)
foreca=ts(foreca,frequency=365,start=c(2684,1))
head(foreca)

final=c(train,foreca)
length(final)
plot(final,type="l",xlim=c(0,2900))
lines(1:2435,train,col=1)
lines(2436:2800,foreca,col="red")


library(e1071)
library(nnfor)
t1=ts(train,frequency=269,start=c(2012,1))
plot(t1)
mlpmodel=mlp(t1)
mlpmodel
accuracy(mlpmodel)

mlpfrc=forecast(mlpmode,h=365)
plot(mlpfrc)



elmmodel=elm(t1)
elmmodel
elmfrc=forecast(elmmodel,h=365)
plot(elmfrc)
accuracy(elmmodel)








###ggplot(data=tr,aes(x=Timepoints,y=train))+geom_line()+labs(y="train",x="Timepoints")+geom_line()+labs(y="for1",x="Time1")
foreca
plot(foreca,xlim=c(0,370),ylim=c(1500,1800))
lines(foreca)


































A2=read.csv("INFY.csv");A2
X2=A2$Close.Price;X2
n2=length(X2);n2
r3=log(X2[2:n2]/X2[1:(n2-1)]);r3
m3=mean(r3)
v3=var(r3)
s3=sqrt(v3);s3
kr3=kurtosis(r3);kr3
sk3=skewness(r3);sk3
summary(r3)
dev.new()
plot(r3,type="l")

A3=read.csv("TCS.csv");A3
X3=A3$Close.Price;X3
n3=length(X3);n3
r4=log(X3[2:n3]/X3[1:(n3-1)]);r4
m4=mean(r4)
v4=var(r4)
s4=sqrt(v4);s4
kr4=kurtosis(r4);kr4
sk4=skewness(r4);sk4
summary(r4)
dev.new()
plot(r4,type="l")

A4=read.csv("HINDUNILVR.csv");A4
X4=A4$Close.Price;X4
n4=length(X4);n4
r5=log(X4[2:n4]/X4[1:(n4-1)]);r5
m5=mean(r5)
v5=var(r5)
s5=sqrt(v5);s5
kr5=kurtosis(r5);kr5
sk5=skewness(r5);sk5
summary(r5)
dev.new()
plot(r5,type="l")

#Portofolio
require(timeSeries)
require(quantmod)
require(slam)
require(fPortfolio)
require(caTools)
library(PerformanceAnalytics)
TickerList<-c("RELIANCE","HDFCBANK","INFY","TCS","HINDUNILVR");TickerList
ClosingPricesRead<-NULL
for(Ticker in TickerList)
  ClosingPricesRead<-cbind(ClosingPricesRead,getSymbols.yahoo(Ticker,from="2011-01-
01",verbose=F,auto.assign=F)[,4])
ClosingPricesRead
ClosingPrices<-
  ClosingPricesRead[apply(ClosingPricesRead,1,function(x)all(!is.na(x))),];ClosingPrices
returns<-as.timeSeries(tail(ClosingPrices,-1)/as.numeric(head(ClosingPrices,-1))-
                         1);head(returns)
summary(returns)
Frontier<-portfolioFrontier(returns)
summary(Frontier)
weig2=c(0.0680,0.5790,0.3529)
weig3=c(0.2834,0.3047,0.4120)
weig4=c(0.4987,0.0303,0.4710)
meanret=c(mean(r1),mean(r2),mean(r3))
expinv2=weig2*100000
obmeanret=0.0007
portret2=(weig2*obmeanret)
plot(Frontier,1)
minVar<-minvariancePortfolio(returns)
summary(minVar)
sp=SharpeRatio(returns)
sd=StdDev(returns)

#Non-parametric Method

alpha1=0.05
S=1000000
sr1=sort(r1)
awRl=alpha1*length(r1)
varRl=-S*(sr1[awRl]);varRl

sr2=sort(r2)
awHDFC=alpha1*length(r2)
varHDFC=-S*(sr2[awHDFC]);varHDFC

sr3=sort(r3)
awINFY=alpha1*length(r3)
varINFY=-S*(sr3[awINFY]);varINFY

sr4=sort(r4)
awTCS=alpha1*length(r4)
varTCS=-S*(sr4[awTCS]);varTCS

sr5=sort(r5)
awHINDU=alpha1*length(r5)
varHINDU=-S*(sr5[awHINDU]);varHINDU
varnp=c(varRl,varHDFC,varINFY,varTCS,varHINDU);varnp

#Parametric Method

VarRlN=-S*qnorm(alpha1,m1,s1)
VarHD=-S*qnorm(alpha1,m2,s2)
VarIN=-S*qnorm(alpha1,m3,s3)
VarTC=-S*qnorm(alpha1,m4,s4)
VarHN=-S*qnorm(alpha1,m5,s5)
varpara=c(VarRlN,VarHD,VarIN,VarTC,VarHN)

Company=c("Reliance","HDFC","INFOSYS","TCS","HINDUNLIVR")
alpha=c(0.05,0.05,0.05,0.05,0.05)
tble=data.frame(Company,alpha,varnp,varpara);tble

#Conditional Value at risk using formula

M1=length(sr1)
w1=alpha1*M1
cvarRl=-S*mean(sr1[1:w1]);cvarRl

M2=length(sr2)
w2=alpha1*M2
cvarHDFC=-S*mean(sr2[1:w2])

M3=length(sr3)
w3=alpha1*M3
cvarINFY=-S*mean(sr3[1:w3])

M4=length(sr4)
w4=alpha1*M4
cvarTCS=-S*mean(sr4[1:w4])

M5=length(sr5)
w5=alpha1*M5
cvarHINDU=-S*mean(sr5[1:w5])
CVaR=c(cvarRl,cvarHDFC,cvarINFY,cvarTCS,cvarHINDU);CVaR

#Conditional value at risk using package

library(PerformanceAnalytics)
summary(r1)
E1=ETL(r1,p=0.95,method="historical");E1
CE1=-E1*S;CE1
E2=ETL(r2,p=0.95,method="historical");E2
CE2=-E2*S;CE2
E3=ETL(r3,p=0.95,method="historical");E3
CE3=-E3*S;CE3
E4=ETL(r4,p=0.95,method="historical");E4
CE4=-E4*S;CE4
E5=ETL(r5,p=0.95,method="historical");E5
CE5=-E5*S;CE5
E=c(E1,E2,E3,E4,E5);E
CE=c("(historical)",CE1,CE2,CE3,CE4,CE5);CE

e1=ETL(r1,p=0.95,method="gaussian");e1
ce1=-e1*S;ce1
e2=ETL(r2,p=0.95,method="gaussian");e2
ce2=-e2*S;ce2
e3=ETL(r3,p=0.95,method="gaussian");e3
ce3=-e3*S;ce3
e4=ETL(r4,p=0.95,method="gaussian");e4
ce4=-e4*S;ce4
e5=ETL(r5,p=0.95,method="gaussian");e5
ce5=-e5*S;ce5
e=c(e1,e2,e3,e4,e5);e
ce=c("(gaussian)",ce1,ce2,ce3,ce4,ce5);ce

tab1=data.frame(Company=c("-","Reliance","HDFC","Infosys","TCS","HINDUNLIVR"),CE,ce,CVaR=c("Formula",cvarRl,cvarHDFC,cvarINFY,cvarTCS,cvarHINDU));tab1

#Model for Reliance
length(r1)
train=r1[1489:2183]
length(train)
test=r1[2184:2682]
length(test)
plot(X,main="plot of closing price",xlab="time points(in days)",ylab="Closing
price",type="l")
acf(X,main="ACF plot of closing price")
plot(train,ylab="log return series",type="l")
par(mfrow=c(1,2))
acf(train,lag=2*sqrt(length(train)),main="ACF of log return series")
pacf(train,lag=2*sqrt(length(train)),main="PACF of log return series")
library(forecast)
auto.arima(train)
fit1=arima(train,order=c(2,0,2))
f1=fit1$residual
lb1=Box.test(f1,lag=2*sqrt(length(train)),type="Ljung-Box")
lb1
info1=fit1$aic
f11=auto.arima(train)$residuals
acf(f11,main="ACF of residual series")
acf(f11^2,main="ACF of squared residual series")
pacf(f11,main="PACF of adjusted log return series")
pacf(f11^2,main="PACF of squared residual series")
library(fGarch)
library(tseries)


# Model for HDFC
length(r2)
train1=r2[1737:2227]
length(train1)
test1=r2[2228:2682]
length(test1)
plot(X1,main="plot of closing price",xlab="time points(in days)",ylab="Closing
price",type="l")
par(mfrow=c(2,2))
acf(train1,lag=2*sqrt(length(train1)),main="ACF of log return series(2)")
pacf(train1,lag=2*sqrt(length(train1)),main="PACF of log return series(2)")
library(forecast)
auto.arima(train1)
fit21=arima(train1,order=c(1,0,1))
f21=fit21$residual
lb21=Box.test(f21,lag=2*sqrt(length(train1)),fitdf=2,type="Ljung-Box")
lb21
info21=fit21$aic
par(mfrow=c(2,2))
f2=auto.arima(train1)$residuals;f2
acf(f21,main="ACF of adjusted log return series")
acf(f21^2,main="ACF of adjusted squared log return series")
pacf(f21,main="PACF of adjusted log return series")
pacf(f21^2,main="PACF of adjusted squared log return series")
library(fGarch)
library(tseries)
gft1=garchFit(~garch(1,1),data=f2,cond.dist=c("snorm"))
summary(gft1)
rs1=residuals(gft1, standardize=T)
l1=Box.test(rs1,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l1

gft2=garchFit(~garch(1,2),data=f2,cond.dist=c("snorm"))
summary(gft2)
rs2=residuals(gft2, standardize=T)
l2=Box.test(rs2,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l2

gft3=garchFit(~garch(1,3),data=f2,cond.dist=c("snorm"))
summary(gft3)
rs3=residuals(gft3, standardize=T)
l3=Box.test(rs3,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l3

gft4=garchFit(~garch(2,1),data=f2,cond.dist=c("snorm"))
summary(gft4)
rs4=residuals(gft4, standardize=T)
l4=Box.test(rs4,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l4

gft5=garchFit(~garch(2,2),data=f2,cond.dist=c("snorm"))
summary(gft5)
rs5=residuals(gft5, standardize=T)
l5=Box.test(rs5,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l5

gft6=garchFit(~garch(2,3),data=f2,cond.dist=c("snorm"))
summary(gft6)
rs6=residuals(gft6, standardize=T)
l6=Box.test(rs6,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l6

gft7=garchFit(~garch(3,1),data=f2,cond.dist=c("snorm"))
summary(gft7)
rs7=residuals(gft7, standardize=T)
l7=Box.test(rs7,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l7

gft8=garchFit(~garch(3,2),data=f2,cond.dist=c("snorm"))
summary(gft8)
rs8=residuals(gft8, standardize=T)
l8=Box.test(rs8,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l8

gft9=garchFit(~garch(3,3),data=f2,cond.dist=c("snorm"))
summary(gft9)
rs9=residuals(gft9, standardize=T)
l9=Box.test(rs9,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l9

gft10=garchFit(~garch(4,1),data=f2,cond.dist=c("snorm"))
summary(gft10)
rs10=residuals(gft10, standardize=T)
l10=Box.test(rs10,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l10

gft11=garchFit(~garch(4,2),data=f2,cond.dist=c("snorm"))
summary(gft11)
rs11=residuals(gft11, standardize=T)
l11=Box.test(rs11,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l11

gft12=garchFit(~garch(4,3),data=f2,cond.dist=c("snorm"))
summary(gft12)
rs12=residuals(gft12, standardize=T)
l12=Box.test(rs12,lag=round(2*sqrt(length(train1))),type="Ljung-Box");l12

ms=c("1,1","1,2","1,3","2,1","2,2","2,3","3,1","3,2","3,3","4,1","4,2","4,3")
aic=c(-5.923034,-5.917596,-5.912610,-5.924964,-5.937714,-5.932059,-5.919231,-5.931660,-5.927585,-5.934883,-5.930409,-5.925934)
B=data.frame("Model for HDFC"=c(1:12),"m,s"=ms,"AIC"=aic);B
vlt2=volatility(gft6);vlt2
rs2=f21/vlt2;rs2
cat("\n Diagnostic cheking of fitted model")
cat("Ljung-Box tset for residual of fitted model")
b21=Box.test(rs2,lag=2*sqrt(length(train1)),type="Ljung-Box")
v2=b21$statistic;v2
tb2=qchisq(1-0.05,2*sqrt(length(train1)))
cat("\n Calculated statistics",v2)
cat("ln Critical value is",tb2)
if(v2>tb2)
  cat("We Reject Ho and hence we conclude that residual series are does not follows white noise series")else
    cat("We Accept Ho and hence we conclude that residual series are follows white noise series")
cat("ln Ljung Box test for square of residual of fitted model")
acf(rs2,lag=2*sqrt(length(train1)),main="ACF of residual of fitted GARCH model")
acf(rs2^2,main="ACF of squared residual of fitted GARCH model")
rs21=rs2^2
b2=Box.test(rs21,lag=2*sqrt(length(train1)),type="Ljung-Box")
v21=b2$statistic;v21
tb21=qchisq(1-0.05,2*sqrt(length(train1)))
cat("\n Calculated statistics",v21)
cat("ln Critical value is",tb21)
if(v21>tb21)
  cat("We Reject Ho and hence we conclude that squared residual series are does not follows white noise series")else
    cat("We Accept Ho and hence we conclude that squared residual series are follows white noise series")

price_forecast=forecast(gft4,h=499)
plot(price_forecast)
accuracy(fit21)

# forecast
pr=predict(gft4, n.ahead =284 , trace = TRUE, mse = c("cond","uncond"),plot=TRUE, nx=NULL, crit_val=NULL, conf=0.95);pr
pr

rr=ts(train1,start=c(2017,1))
rr
f=fitted(gft6);f
f1=ts(f,start=c(2017,1))
plot.ts(rr,type="l",ylim=c(-0.2,0.2))
lines(f1 ,type="p")

#forecast volatility
a01=1.581e-01
a11=2.166e-01
b11=3.944e-01
sp1={}
sp1[1]=a01+a11*(f2[447]^2)+b11*(vlt2[447]^2)
for(i in 2:length(train1))
  sp1[i]=a01+(a11+b11)*sp1[i-1]
cat("\n Predicted volatility",sp1)




#Model for Infosys

length(r3)
train2=r3[2184:2435]
train2
test2=r3[2436:2682]
length(test2)
plot(X2,main="plot of closing price",xlab="time points(in days)",ylab="Closing
price",type="l")
par(mfrow=c(2,2))
acf(train2,lag=2*sqrt(length(train2)),main="ACF of log return series(2)")
pacf(train2,lag=2*sqrt(length(train2)),main="PACF of log return series(2)")
auto.arima(train1)
fitInf21=arima(train2,order=c(1,0,2))
fInf21=fitInf21$residual
lbInf21=Box.test(fInf21,lag=2*sqrt(length(train2)),type="Ljung-Box")
lbInf21
infoInf21=fitInf21$aic
par(mfrow=c(2,2))
fInf2=auto.arima(train2)$residuals
acf(fInf21,main="ACF of adjusted log return series")
acf(fInf21^2,main="ACF of adjusted squared log return series")
pacf(fInf21,main="PACF of adjusted log return series")
pacf(fInf21^2,main="PACF of adjusted squared log return series")
library(fGarch)
library(tseries)
gftI1=garchFit(~garch(1,1),data=fInf2,cond.dist=c("snorm"))
summary(gftI1)
gftI2=garchFit(~garch(1,2),data=fInf2,cond.dist=c("snorm"))
summary(gftI2)
gftI3=garchFit(~garch(1,3),data=fInf2,cond.dist=c("snorm"))
summary(gftI3)
gftI4=garchFit(~garch(1,4),data=fInf2,cond.dist=c("snorm"))
summary(gftI4)
gftI5=garchFit(~garch(2,1),data=fInf2,cond.dist=c("snorm"))
summary(gftI5)
gftI6=garchFit(~garch(2,2),data=fInf2,cond.dist=c("snorm"))
summary(gftI6)
gftI7=garchFit(~garch(2,3),data=fInf2,cond.dist=c("snorm"))
summary(gftI7)
gftI8=garchFit(~garch(2,4),data=fInf2,cond.dist=c("snorm"))
summary(gftI8)
msInf=c("1,1","1,2","1,3","1,4","2,1","2,2","2,3","2,4")
aicInf=c(-4.979821,-4.976063,-4.977460,-4.977539,-4.973183,-4.968126,-4.969523,-4.970940)
BInf=data.frame("Model for Infosys"=c(1:8),"m,s"=msInf,"AIC"=aicInf);BInf
vltInf=volatility(gftI1);vltInf
rsInf=fInf21/vltInf;rsInf
cat("\n Diagnostic cheking of fitted model")
cat("Ljung-Box tset for residual of fitted model")
bInf21=Box.test(rsInf,lag=2*sqrt(length(train2)),type="Ljung-Box")
vInf2=bInf21$statistic;vInf2
tbInf2=qchisq(1-0.05,2*sqrt(length(train2)))
cat("\n Calculated statistics",vInf2)
cat("ln Critical value is",tbInf2)
if(vInf2>tbInf2)
  cat("We Reject Ho and hence we conclude that residual series are does not follows white noise series")else
    cat("We Accept Ho and hence we conclude that residual series are follows white noise series")
cat("\n Ljung Box test for square of residual of fitted model")
acf(rsInf,lag=2*sqrt(length(train2)),main="ACF of residual of fitted GARCH model")
acf(rsInf^2,main="ACF of squared residual of fitted GARCH model")
rsInf21=rsInf^2
bInf2=Box.test(rsInf21,lag=2*sqrt(length(train2)),type="Ljung-Box")
vInf21=bInf2$statistic;v21
tbInf21=qchisq(1-0.05,2*sqrt(length(train2)))
cat("\n Calculated statistics",vInf21)
cat("ln Critical value is",tbInf21)
if(vInf21>tbInf21)
  cat("We Reject Ho and hence we conclude that squared residual series are does not follows white noise series")else
    cat("We Accept Ho and hence we conclude that squared residual series are follows white noise series")
#forecast volatility
Ialpha=4.162e-01
Ibeta=4.492e-01
spI={}
spI[1]=Ialpha+a11*(f2[400]^2)+b11*(vlt2[400]^2)

for(i in 2:2683)
  sp1[i]=a01+(a11+b11)*sp1[i-1]
sp1
cat("\n Predicted volatility",spI1)

#Model for TCS

length(r4)
train3=r4[2050:2435]
train3
test3=r4[2436:2682]
length(test3)
plot(X3,main="plot of closing price",xlab="time points(in days)",ylab="Closing
price",type="l")
par(mfrow=c(2,2))
acf(train3,lag=2*sqrt(length(train3)),main="ACF of log return series(2)")
pacf(train3,lag=2*sqrt(length(train3)),main="PACF of log return series(2)")
auto.arima(train3)
fitTcs21=arima(train3,order=c(0,0,1))
fTcs21=fitTcs21$residual
lbTcs21=Box.test(fTcs21,lag=2*sqrt(length(train3)),type="Ljung-Box")
lbTcs21
infoTcs21=fitTcs21$aic
par(mfrow=c(2,2))
fTcs2=auto.arima(train3)$residuals
acf(fTcs2,main="ACF of adjusted log return series")
acf(fTcs2^2,main="ACF of adjusted squared log return series")
pacf(fTcs2,main="PACF of adjusted log return series")
pacf(fTcs2^2,main="PACF of adjusted squared log return series")
library(fGarch)
library(tseries)
gftT1=garchFit(~garch(1,1),data=fTcs2,cond.dist=c("snorm"))
summary(gftT1)
gftT2=garchFit(~garch(1,2),data=fTcs2,cond.dist=c("snorm"))
summary(gftT2)
gftT3=garchFit(~garch(2,1),data=fTcs2,cond.dist=c("snorm"))
summary(gftT3)
gftT4=garchFit(~garch(1,4),data=fTcs2,cond.dist=c("snorm"))
summary(gftT4)
msTcs=c("1,1","1,2","2,1","2,2")
aicTcs=c(-5.185959,-5.180609,-5.182716,-5.172249)
BTcs=data.frame("Model for Infosys"=c(1:8),"m,s"=msInf,"AIC"=aicInf);BInf
vltTcs=volatility(gftT1);vltTcs
rsTcs=fTcs21/vltTcs;rsTcs
cat("\n Diagnostic cheking of fitted model")
cat("Ljung-Box tset for residual of fitted model")
bTcs21=Box.test(rsTcs,lag=2*sqrt(length(train3)),type="Ljung-Box")
vTcs2=bTcs21$statistic;vTcs2
tbTcs2=qchisq(1-0.05,2*sqrt(length(train3)))
cat("\n Calculated statistics",vTcs2)
cat("ln Critical value is",tbTcs2)
if(vTcs2>tbTcs2)
  cat("We Reject Ho and hence we conclude that residual series are does not follows white noise series")else
    cat("We Accept Ho and hence we conclude that residual series are follows white noise series")
cat("\n Ljung Box test for square of residual of fitted model")
acf(rsTcs,lag=2*sqrt(length(train3)),main="ACF of residual of fitted GARCH model")
acf(rsTcs^2,main="ACF of squared residual of fitted GARCH model")
rsTcs21=rsTcs^2
bTcs2=Box.test(rsTcs21,lag=2*sqrt(length(train3)),type="Ljung-Box")
vTcs21=bInf2$statistic;vTcs21
tbTcs21=qchisq(1-0.05,2*sqrt(length(train3)))
cat("\n Calculated statistics",vTcs21)
cat("ln Critical value is",tbTcs21)
if(vTcs21>tbTcs21)
  cat("We Reject Ho and hence we conclude that squared residual series are does not follows white noise series")else
    cat("We Accept Ho and hence we conclude that squared residual series are follows white noise series")


# model for Hindunilvr
length(r5)
train4=r5[1940:2435]
train4
test4=r5[2436:2682]
length(test4)
plot(X4,main="plot of closing price",xlab="time points(in days)",ylab="Closing
price",type="l")
par(mfrow=c(2,2))
acf(train4,lag=2*sqrt(length(train4)),main="ACF of log return series(2)")
pacf(train4,lag=2*sqrt(length(train4)),main="PACF of log return series(2)")
auto.arima(train4)
fitHn21=arima(train4,order=c(1,0,2))
fHn21=fitHn21$residual
lbHn21=Box.test(fHn21,lag=2*sqrt(length(train4)),type="Ljung-Box")
lbHn21
infoHn21=fitHn21$aic
par(mfrow=c(2,2))
fHn2=auto.arima(train4)$residuals
acf(fHn21,main="ACF of adjusted log return series")
acf(fHn21^2,main="ACF of adjusted squared log return series")
pacf(fHn21,main="PACF of adjusted log return series")
pacf(fHn21^2,main="PACF of adjusted squared log return series")
library(fGarch)
library(tseries)
gftI1=garchFit(~garch(1,1),data=fInf2,cond.dist=c("snorm"))
summary(gftI1)
gftI2=garchFit(~garch(1,2),data=fInf2,cond.dist=c("snorm"))
summary(gftI2)
gftI3=garchFit(~garch(1,3),data=fInf2,cond.dist=c("snorm"))
summary(gftI3)
gftI4=garchFit(~garch(1,4),data=fInf2,cond.dist=c("snorm"))
summary(gftI4)
gftI5=garchFit(~garch(2,1),data=fInf2,cond.dist=c("snorm"))
summary(gftI5)
gftI6=garchFit(~garch(2,2),data=fInf2,cond.dist=c("snorm"))
summary(gftI6)
gftI7=garchFit(~garch(2,3),data=fInf2,cond.dist=c("snorm"))
summary(gftI7)
gftI8=garchFit(~garch(2,4),data=fInf2,cond.dist=c("snorm"))
summary(gftI8)
msInf=c("1,1","1,2","1,3","1,4","2,1","2,2","2,3","2,4")
aicInf=c(-4.979821,-4.976063,-4.977460,-4.977539,-4.973183,-4.968126,-4.969523,-4.970940)
BInf=data.frame("Model for Infosys"=c(1:8),"m,s"=msInf,"AIC"=aicInf);BInf
vltInf=volatility(gftI1);vltInf
rsInf=fInf21/vltInf;rsInf
cat("\n Diagnostic cheking of fitted model")
cat("Ljung-Box tset for residual of fitted model")
bInf21=Box.test(rsInf,lag=2*sqrt(length(train2)),type="Ljung-Box")
vInf2=bInf21$statistic;vInf2
tbInf2=qchisq(1-0.05,2*sqrt(length(train2)))
cat("\n Calculated statistics",vInf2)
cat("ln Critical value is",tbInf2)
if(vInf2>tbInf2)
  cat("We Reject Ho and hence we conclude that residual series are does not follows white noise series")else
    cat("We Accept Ho and hence we conclude that residual series are follows white noise series")
cat("\n Ljung Box test for square of residual of fitted model")
acf(rsInf,lag=2*sqrt(length(train2)),main="ACF of residual of fitted GARCH model")
acf(rsInf^2,main="ACF of squared residual of fitted GARCH model")
rsInf21=rsInf^2
bInf2=Box.test(rsInf21,lag=2*sqrt(length(train2)),type="Ljung-Box")
vInf21=bInf2$statistic;v21
tbInf21=qchisq(1-0.05,2*sqrt(length(train2)))
cat("\n Calculated statistics",vInf21)
cat("ln Critical value is",tbInf21)
if(vInf21>tbInf21)
  cat("We Reject Ho and hence we conclude that squared residual series are does not follows white noise series")else
    cat("We Accept Ho and hence we conclude that squared residual series are follows white noise series")