
A1=read.csv("HDFC.csv");A1
X1=A1$Close.Price;X1

n1=length(X1);n1
xt=ts(X1,frequency=269,start=c(2012))
plot.ts(xt,main="Closing price of HDFC",xlab="Time points(in days)",ylab="Closing Price")

train=xt[249:2683]

##TREND
library(Kendall)
summary(MannKendall(train))
pvalue=0.00000000000000222
if(pvalue<0.05)
  cat("\n There is trend \n")else
    cat("\n There is no trend \n")
library(forecast)
auto.arima(xt,d=NA)
v=var(train);v
d1=diff(train)
v1=var(d1);v1

d2=diff(d1);d2
v2=var(d2);v2
par(mfrow=c(1,2))
acf(d2)
pacf(d2)
fit1=arima(train,order=c(17,1,2))
fi1=fitted(fit1)
b1=Box.test(fit1$residual,lag=2*sqrt(length(train)),type="Ljung-Box")
b1

res=fit1$residuals
par(mfrow=c(2,2))
res
acf(res,main="ACF of Residuals")
acf(res^2,main="ACF of squared Residuals ")
pacf(res,main="PACF of  Residuals")
pacf(res^2,main="PACF of Squared Residuals")
library(fGarch)
library(tseries)
gft1=garchFit(~garch(3,4),data=res,cond.dist=c("snorm"))
summary(gft1)
rs1=residuals(gft1, standardize=T)
l1=Box.test(rs1,lag=round(2*sqrt(length(train))),type="Ljung-Box");l1
ms=c("1,1","1,2","2,1","2,2","3,1","3,2","3,4","4,1","4,2")
aic=c(8.217264,8.218140,8.218607,8.218664,8.219921,8.219986,8.214809,8.221235,8.221293)
pvl=c(0.4915,0.5063,0.4915,0.4968,0.4915,0.497,0.5368,0.4914,0.4969)
B=data.frame("Model for HDFC"=c(1:9),"m,s"=ms,"AIC"=aic,"p value"=pvl);B

pr=predict(gft1, n.ahead =365 , trace = TRUE, mse = c("cond","uncond"),plot=TRUE, nx=NULL, crit_val=NULL, conf=0.95);pr
pr
pr1=data.frame(pr)
attach(pr1)
PointFor1=pr1[,1]
print(pr1)
testpred=forecast(fit1,h=365);testpred
testpred1=data.frame(testpred)
attach(testpred1)
PointFor=testpred1[,1]
print(testpred1)
foreca=PointFor+PointFor1;foreca
for1=data.frame(foreca)
for1
plot(foreca)
foreca1=ts(foreca,frequency=269,start=c(2022))
head(foreca1)

final=c(train,foreca1)
class(final)
final1=ts(final,frequency = 269,start=c(2012))
final1
class(final1)
length(final)
plot.ts(final1,type="l",xlim=c(2011,2024),ylim=c(500,4000),ylab="Closing Price")
par(new=TRUE)
plot(foreca1,xlim=c(2011,2024),ylim=c(500,4000),col="red",ylab="Closing Price")
accuracy(fit1)

library(nnfor)
head(train)
class(train)
train1=ts(train,frequency = 269,start=c(2012))
class(train1)
mllfit=elm(train1)
mllfit

#Hybrid Method
library(forecastHybrid)
train=ts(train,frequency=269,start=(2011))
mod1=hybridModel(train,model="an")
fore=forecast(mod1,h=269)
fore1=ts(fore,frequency=269,start=c(2021))
plot(fore,xlim=c(2011,2023),xlab="Time",ylab="Closing Price")
accuracy(fore)

#
v1=volatility(gft1);v1
V=fi1+v1;V
plot(train,type="p")
lines(V,col=2)
