A=read.csv("Reliance.csv");A
X=A$Close.Price;X
n=length(X);n
xt=ts(X,frequency=269,start=c(2012))
plot.ts(xt,main="close price of Reliance",xlab="Time points(in days)",ylab="Closing Price")

train=xt[249:2683]
##TREND
library(Kendall)
summary(MannKendall(train))
pvalue=2.22e-16
if(pvalue<0.05)
  cat("\n There is trend \n")else
    cat("\n There is no trend \n")
library(forecast)
auto.arima(xt,d=NA)
v=var(train);v
d1=diff(train)
v1=var(d1);v1
d2=diff(d1);d2
v2=var(d2);v2
par(mfrow=c(2,2))
acf(d2,main="ACF of Closing price")
pacf(d2,main="PACF of Closing price")
fit1=arima(train,order=c(12,1,1))
fi1=fitted(fit1)
b1=Box.test(fit1$residual,lag=2*sqrt(length(train)),type="Ljung-Box")
b1

res=fit1$residuals
par(mfrow=c(2,2))
res
acf(res,main="ACF of Residuals")
acf(res^2,main="ACF of Squared Residuals")
pacf(res,main="PACF of Residuals")
pacf(res^2,main="PACF of Squared Residuals")
library(fGarch)
library(tseries)
gft1=garchFit(~garch(1,2),data=res,cond.dist=c("snorm"))
summary(gft1)
rs1=residuals(gft1, standardize=T)
l1=Box.test(rs1,lag=round(2*sqrt(length(train))),type="Ljung-Box");l1
ms=c("1,1","1,2","1,3","2,1","2,2","3,1","3,2","4,1","5,1")
aic=c(8.7821268,8.780279,8.780541,8.783084,8.781100,8.784011,8.782035,8.784885,8.785742)
pvl=c(0.4308,0.4161,0.4089,0.428,0.4161,0.4256,0.4134,0.4246,0.4238)
B=data.frame("Model for HDFC"=c(1:9),"m,s"=ms,"AIC"=aic,"p value"=pvl);B

pr=predict(gft1, n.ahead =365 , trace = TRUE, mse = c("cond","uncond"),plot=TRUE, nx=NULL, crit_val=NULL, conf=0.95);pr
pr
pr1=data.frame(pr)
attach(pr1)
PointFor1=pr1[,1]
print(pr1)
testpred=forecast(fit1,h=365);testpred
testpred1=data.frame(testpred)
attach(testpred1)
PointFor=testpred1[,1]
print(testpred1)
foreca=PointFor+PointFor1;foreca
for1=data.frame(foreca)
plot(foreca)
foreca=ts(foreca,frequency=269,start=c(2021))
head(foreca)

final=c(train,foreca)
length(final)
final1=ts(final,frequency=269,start=c(2012))
plot.ts(final1,main="Forecast from ARIMA-GARCH Model",type="l",xlim=c(2011,2022),ylab="Closing price")
lines(foreca,col="red")
accuracy(fit1)

library(e1071)
library(nnfor)
head(train)
class(train)
train1=ts(train,frequency = 269,start=c(2012,1))
class(train1)
elmfit=elm(train1)
elmfit

#Hybrid Method

library(forecastHybrid)
train=ts(train,frequency=269,start=(2011))
mod1=hybridModel(train,model="an")
fore=forecast(mod1,h=269)
fore1=ts(fore,frequency=269,start=c(2021))
plot(fore,xlim=c(2011,2023),xlab="Time",ylab="Closing Price")
accuracy(fore)

