start_time <- Sys.time()

# #install.packages("pacman")
# library("pacman")

#Check for and install required packages, using pacman
#if (!require("pacman")) install.packages("pacman")
#pacman::p_load() #No packages required :)

#tradingData <- read.csv("C:/Users/G/Google Drive/aStThomas/6MachineLearning/Assignments/R/7 kmeans/NYSE_DM.csv", header = TRUE)

#Preview structure
str(tradingData)

#Preview top 5 rows
head(tradingData, n=5)

#give col names
colnames(tradingData) <- c("ID","OPEN_P", "HIGH_P", "LOW_P", "CLOSE_P", "VOLUME", "CLOSE_ADJ_P")

#drop ID column
tradingData <- tradingData[, -c(1)]

#standardize the continuous numbers
tradingData <- scale(tradingData)

#perform kmeans with k = 4
fit <- kmeans(tradingData, centers = 4, iter.max = 10000)

#display the results, taken from the fit table centers
fit$centers
View(fit$centers)

#stop watch
end_time <- Sys.time()
total_time <- end_time - start_time
total_time





library(quantmod)
stock = getSymbols("AAPL",src='yahoo',from = '2015-07-01', auto.assign = F)
dtw_cluster = tsclust(normalized_price, type="partitional",k=5,
                      distance="dtw_basic",centroid = "pam",seed=1234,trace=T,
                      args = tsclust_args(dist = list(window.size = 5)))


